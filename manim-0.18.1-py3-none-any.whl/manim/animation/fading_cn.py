from ..animation.fading import *

__all__ = ["淡出","淡入"]
class 淡出(FadeOut):
        pass
class 淡入(FadeIn):
        pass

