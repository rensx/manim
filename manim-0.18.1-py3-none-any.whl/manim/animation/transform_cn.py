from ..animation.transform import *
__all__ = ["转换","置换变换","从副本转换","顺时针变换","逆时针变换","移动到目标","应用方法","应用逐点函数","应用逐点函数到中心","渐变色","渐变变换","渐变变换片段","就地缩放","收缩到中心","恢复","应用函数","应用矩阵","应用复杂函数","循环替换","交换","变换动画"]
class 转换(Transform):
	pass
class 置换变换(ReplacementTransform):
	pass
class 从副本转换(TransformFromCopy):
	pass
class 顺时针变换(ClockwiseTransform):
	pass
class 逆时针变换(CounterclockwiseTransform):
	pass
class 移动到目标(MoveToTarget):
	pass
class 应用方法(ApplyMethod):
	pass
class 应用逐点函数(ApplyPointwiseFunction):
	pass
class 应用逐点函数到中心(ApplyPointwiseFunctionToCenter):
	pass
class 渐变色(FadeToColor):
	pass
class 渐变变换(FadeTransform):
	pass
class 渐变变换片段(FadeTransformPieces):
	pass
class 就地缩放(ScaleInPlace):
	pass
class 收缩到中心(ShrinkToCenter):
	pass
class 恢复(Restore):
	pass
class 应用函数(ApplyFunction):
	pass
class 应用矩阵(ApplyMatrix):
	pass
class 应用复杂函数(ApplyComplexFunction):
	pass
class 循环替换(CyclicReplace):
	pass
class 交换(Swap):
	pass
class 变换动画(TransformAnimations):
	pass
