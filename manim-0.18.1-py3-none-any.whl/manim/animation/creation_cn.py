from ..animation.creation import *
__all__ = ["创建","取消创建","绘制边框然后填充","写","取消写入","显示部分","显示增加的子集","螺旋输入","逐个字母添加文字","逐个字母地删除文本","逐个显示子对象","逐个字添加文字"]
class 创建(Create):
	pass
class 取消创建(Uncreate):
	pass
class 绘制边框然后填充(DrawBorderThenFill):
	pass
class 写(Write):
	pass
class 取消写入(Unwrite):
	pass
class 显示部分(ShowPartial):
	pass
class 显示增加的子集(ShowIncreasingSubsets):
	pass
class 螺旋输入(SpiralIn):
	pass
class 逐个字母添加文字(AddTextLetterByLetter):
	pass
class 逐个字母地删除文本(RemoveTextLetterByLetter):
	pass
class 逐个显示子对象(ShowSubmobjectsOneByOne):
	pass
class 逐个字添加文字(AddTextWordByWord):
	pass
