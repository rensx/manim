from ..geometry.polygram import *
__all__ = ["多边形","正多边形","星星","星形","三角形","长方形","正方形","圆角矩形","剪切块"]
class 多边形(Polygon):
	pass
class 正多边形(RegularPolygon):
	pass
class 星星(Star):
	pass
class 星形(Star):
	pass
class 三角形(Triangle):
	pass
class 长方形(Rectangle):
	pass
class 正方形(Square):
	pass
class 圆角矩形(RoundedRectangle):
	pass
class 剪切块(Cutout):
	pass
