from ..geometry.shape_matchers import *
__all__ = ["环绕矩形","背景矩形","叉","下划线"]
class 环绕矩形(SurroundingRectangle):
	pass
class 背景矩形(BackgroundRectangle):
	pass
class 叉(Cross):
	pass
class 下划线(Underline):
	pass
