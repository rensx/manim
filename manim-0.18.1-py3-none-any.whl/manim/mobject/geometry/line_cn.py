from ..geometry.line import *
__all__ = ["线","虚线","切线","弯头","箭","向量","双箭头","角度","直角"]
class 线(Line):
	pass
class 虚线(DashedLine):
	pass
class 切线(TangentLine):
	pass
class 弯头(Elbow):
	pass
class 箭(Arrow):
	pass
class 向量(Vector):
	pass
class 双箭头(DoubleArrow):
	pass
class 角度(Angle):
	pass
class 直角(RightAngle):
	pass
