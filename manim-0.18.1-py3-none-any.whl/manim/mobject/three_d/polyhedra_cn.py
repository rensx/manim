from ..three_d.polyhedra import *
__all__ = ["多面体","四面体","八面体","二十面体","十二面体"]
class 多面体(Polyhedron):
	pass
class 四面体(Tetrahedron):
	pass
class 八面体(Octahedron):
	pass
class 二十面体(Icosahedron):
	pass
class 十二面体(Dodecahedron):
	pass
