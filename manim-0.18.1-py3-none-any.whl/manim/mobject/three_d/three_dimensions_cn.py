from ..three_d.three_dimensions import *
__all__ = ["表面","球","立方体","棱镜","锥体","圆柱","三维直线","圆环"]
class 表面(Surface):
	pass
class 球(Sphere):
	pass
class 立方体(Cube):
	pass
class 棱镜(Prism):
	pass
class 锥体(Cone):
	pass
class 圆柱(Cylinder):
	pass
class 三维直线(Line3D):
	pass
class 圆环(Torus):
	pass
